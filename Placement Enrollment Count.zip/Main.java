
import java.util.Scanner;
import java.util.stream.Stream;

public class Main {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		// Fill your code here

		System.out.println("Enter all roll numbers separated by comma");
		String input = s.nextLine().trim();

		System.out.println("Enter the department name acronym");
		String deptName = s.next();

		int studentCount = getCount(getRollNumbers(input), deptName);

		if (studentCount > 0)
			System.out.println("Number of students in " + deptName + " is " + studentCount);
		else
			System.out.println("No students from " + deptName);

		s.close();
	}

	public static Stream<String> getRollNumbers(String rollNumbers) {
		// Fill your code here

		return Stream.of(rollNumbers.split(","));
	}

	public static int getCount(Stream<String> rollNumberStream, String dept) {
		// Fill your code here

		return (int) rollNumberStream.filter(rolNum -> dept.equalsIgnoreCase(rolNum.substring(0, 2))).count();
	}

}
