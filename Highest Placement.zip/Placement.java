import java.util.Scanner;
public class Placement {
    public static void main(String[] args) {
                
                Scanner input = new Scanner(System.in);
                int high = 0;
                
                System.out.println("Enter the no of students placed in CSE:");
                int c = input.nextInt();
                
                System.out.println("Enter the no of students placed in ECE:");
                int e = input.nextInt();
                
                System.out.println("Enter the no of students placed in MECH:");
                int m = input.nextInt();
                
                if(c < 0 || e<0 || m<0){
                    System.out.println("Input is Invalid");
                }
                
                else if(c == m && e==m && c==e){
                    System.out.println("None of the department has got the highest placement");
                }
                else{
                    System.out.println("Highest placement");
                    if(c>=e && c>=m ){
                        high = c;
                        System.out.println("CSE");
                        if(c==e){
                            System.out.println("ECE");
                        }
                        if(c==m){
                            System.out.println("MECH");
                        }
                    }
                    else if(e>=c && e>=m){
                        high = e;
                        System.out.println("ECE");
                        if(e==m){
                            System.out.println("MECH");
                        }
                    }
                    else{
                       high = m;
                        System.out.println("MECH");
                    }
                    
                }
                
        
                
    }
}
