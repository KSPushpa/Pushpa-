import java.util.*;
import java.sql.*;
public class FlightManagementSystem{
    public  boolean addFlight(Flight flightObj){
        int resultSet=0;
        try{
            Connection conn = DB.getConnection();
            Statement stmt = conn.createStatement();
            String id=Integer.toString(flightObj.getFlightId());
            String ffare = Double.toString(flightObj.getFlightFare());
            String nseats = Integer.toString(flightObj.getNoOfSeats());
            String dest=flightObj.getDestination();
            String sou = flightObj.getSource();
            resultSet=stmt.executeUpdate("Insert into flight values("+id+",'"+sou+"','"+dest+"','"+nseats+"','"+ffare+"')");
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return (resultSet==1)?true:false;
    }
}