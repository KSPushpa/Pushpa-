import java.util.*;
public class Main{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        //Flight f=new Flight();
        int id=sc.nextInt();
        //f.setFlightId(id);
        String source=sc.next();
        String destination=sc.next();
        int noOfSeats=sc.nextInt();
        double flightFare=sc.nextDouble();
        Flight f=new Flight(id,source,destination,noOfSeats,flightFare);
        FlightManagementSystem fm=new FlightManagementSystem();
        boolean b=fm.addFlight(f);
        if(b){
            System.out.println("Flight details added successfully");
        }
        else{
            System.out.println("Addition not done");
        }
    }
}