import java.util.*;
public class UserInterface {
   public static void main(String args[]) {
     Scanner sc=new Scanner(System.in);
     
    // Fill the code here
    System.out.println("Enter the no of passengers");
    int n=sc.nextInt();
    int j=1;
   
    double commission[]=new double[n];
    for(int i=0;i<n;i++){
        System.out.println("Details of Passenger "+(j)+":");
        j++;
        System.out.println("Enter the pnr no:");
        long pnrNo=sc.nextLong();
        System.out.println("Enter passenger name:");
        String passengerName=sc.next();
        System.out.println("Enter seat no:");
        int seatNo=sc.nextInt();
        System.out.println("Enter class type:");
        String classType=sc.next();
        System.out.println("Enter ticket fare:");
        double ticketFare=sc.nextDouble();
        Ticket t[] = new Ticket[n];
        t[i]=new Ticket(pnrNo,passengerName,seatNo,classType,ticketFare);
        
        commission[i]=generateCommissionObtained().calculateCommissionAmount(t[i]);
        
    }
    
    
    double sum=0;
    for(int i=0;i<commission.length;i++){
        sum=sum+commission[i];
    }
    System.out.println("Commission Obtained");
    System.out.printf("Commission obtained per each person: Rs.%.2f",sum);
    }
    
    public static CommissionInfo generateCommissionObtained (){
        CommissionInfo obj=(Ticket ticketObj)->{
            
            double commission=0;
            String t=ticketObj.getClassType();
            if(t.equalsIgnoreCase("SL") || t.equalsIgnoreCase("2S")){
                commission=commission+60;
                
                
            }
            else if(t.equalsIgnoreCase("1A")||t.equalsIgnoreCase("2A")||t.equalsIgnoreCase("3A")){
                commission=commission+100;
            }
            return commission;
        };
        return obj;
    }
    
}