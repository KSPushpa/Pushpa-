import java.sql.*;

public class DBHandler {
    
	public Connection establishConnection() 
	{
		
		
	}
}
