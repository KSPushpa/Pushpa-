import java.util.List;
import java.util.*;
import java.sql.*;
public class PlayerSelectionSystem {

	public List<String> playersBasedOnHeightWeight (double minHeight, double maxWeight){
		Player p=new Player();
		// Fill your code here	
		List<String> name=new ArrayList<>();
		try{
		    Connection conn=DB.getConnection();
		    Statement stmt=conn.createStatement();
		    String s="select playerName from player where height>="+minHeight+" && weight<="+maxWeight+" order by playerName asc";
		    ResultSet rs=stmt.executeQuery(s);
		    while(rs.next()){
		        
		        String pn=rs.getString("playerName");
		        name.add(pn);
		    }
		    if(name.isEmpty()){
		        System.out.println("No players are with minimum height of "+ minHeight +" and maximum weight of "+maxWeight);
		    }
		    for(String n:name){
		    System.out.println(n);
		    }
		
		}
		catch(Exception e){
		    e.printStackTrace();
		}
		
		return name;
	}
}
