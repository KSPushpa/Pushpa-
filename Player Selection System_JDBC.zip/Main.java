import java.util.*;
public class Main {
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
		// fill your code here
        System.out.println("Enter the minimum height");
        double minHeight=sc.nextDouble();
        System.out.println("Enter the maximum weight");
        double maxWeight=sc.nextDouble();
		PlayerSelectionSystem ps= new PlayerSelectionSystem();
		ps.playersBasedOnHeightWeight(minHeight,maxWeight);
	}
}