import java.util.*;
public class ValidateUtility
{
    public static void main(String args[])
    {
        //fill code here
        Scanner sc=new Scanner(System.in);
        String employeeName=sc.nextLine();
        String productName=sc.nextLine();
       validateEmployeeName().validateName(employeeName);
        validateProductName().validateName(productName);
    }
    
    public static Validate validateEmployeeName() 
    {
        //fill code here
        Validate obj=(String name)->{
            if(name.matches("^[A-Za-z ]{5,20}$")){
                System.out.println("Employee name is valid");
                return true;
            }
            else{
                System.out.println("Employee name is invalid");
                return false;
            }
        };
        return obj;
    }
    
    public static Validate validateProductName() 
    {
        //fill code here
        Validate obj=(String name)->{
            if(name.matches("^[a-zAA-Z]{1}[0-9]{5}$")){
                System.out.println("Product name is valid");
                return true;
            }
            else{
                System.out.println("Product name is invalid");
                return false;
            }
        };
        return obj;
    }
}