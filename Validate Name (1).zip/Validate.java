public interface Validate{
    //write the abstract method 
    public boolean validateName(String name);
}