import java.io.*;
import java.util.*;
import java.util.Arrays; 
import java.util.Collections;
public class HighestMarkPerSem{
    public static void main (String[] args) throws IOException {
        /* code */
       BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter no of semester:");
        int range= Integer.parseInt(br.readLine());
        int[] arr = new int[range+1];
        int i=1;
        while(i<=range)
            {
               System.out.println("Enter no of subjects in "+i+" semester:");
               int q=Integer.parseInt(br.readLine());
               arr[i]=q;
               i++;
            }
            int[] max = new int[range];
            int j=0;
            int d=1;
            
            while(d<=range)
            {
                System.out.println("Marks obtained in semester "+d+":");
                int limit=arr[d];
                int[] arr1= new int[limit+1];
                for(int p=0;p<limit;p++)
                {
                   
                   int s=Integer.parseInt(br.readLine()); 
                   if(s>0 && s<=100)
                   {
                     arr1[p]=s;  
                   }
                   else
                   {
                       System.out.println("You have entered invalid mark.");
                       System.exit(0);
                   }
                }
                int maxi = arr1[0];
                for(int k = 1;k<limit+1 ;k++)
                               {
                                               if(arr1[k] > maxi)
                                               {
                                                               maxi = arr1[k];
                                               }
                               }
               //System.out.println("max in "+d+" is "+maxi);   
                max[j++]=maxi;
                d++;
            }
            for(int r=0;r<range;r++)
            {
                System.out.printf("Maximum mark in %d semester:",r+1);
                System.out.printf("%d",max[r]);
                System.out.printf("\n");
                
            }
    }
}
