import java.util.*;
public class ArrayException{
    String str="";
    Scanner in = new Scanner(System.in); 
    public String getPriceDetails(){
         try{
             System.out.println("Enter the number of elements in the array");
             int n=in.nextInt();
             int arr[]=new int[n];
             System.out.println("Enter the price details");
             for(int j=0;j<n;j++)
             {
                arr[j]= in.nextInt();
             }
             System.out.println("Enter the index of the array element you want to access");
             int k=in.nextInt();
             return "The array element is "+arr[k];
         }
         catch(ArrayIndexOutOfBoundsException e){
             return "Array index is out of range";
         }
         catch(InputMismatchException e){
             return "Input was not in the correct format";
         }
    }
    public static void main(String[] args){
        ArrayException a =new ArrayException();
        System.out.println(a.getPriceDetails());
    }
}
