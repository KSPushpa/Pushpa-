import java.util.*;

public class Main {
	public static void main(String[] args) throws InterruptedException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of employees");
		int n = sc.nextInt();
//		sc.nextLine();
		System.out.println("Enter the employee details");
		String[] strArr = new String[n];
		for (int i = 0; i < n; i++) {
			strArr[i] = sc.next();
		}
		System.out.println("Enter the number of times salary limit to be searched");
		int n1 = sc.nextInt();
		double[] limitArr = new double[n1];
		for (int j = 0; j < n1; j++) {
			System.out.println("Enter the salary limit to be searched");
			limitArr[j] = sc.nextDouble();
		}
//		Management m = new Management();
		List<Employee> empList = new ArrayList<Employee>();
		for (int k = 0; k < n; k++) {
			String[] arr = strArr[k].split(":");
			Employee e = new Employee(arr[0], arr[1], Double.valueOf(arr[2]));
			empList.add(e);
		}
		Management[] mArr = new Management[n1];
		for (int i = 0; i < n1; i++) {
			mArr[i] = new Management(limitArr[i],empList);
			mArr[i].start();
			mArr[i].join();
		}
		for(int i=0;i<n1;i++) {
			System.out.println(limitArr[i]+" : "+mArr[i].getCount());
		}
	}
}
