import java.util.List;

public class RainfallReport {

	//Write the required business logic as expected in the question description
	public List<AnnualRainfall> generateRainfallReport(String filePath) {
	    
		//fill the code
		
	}
	
	public List<AnnualRainfall>  findMaximumRainfallCities() {
	
		//fill the code
		
	}
	
	
	public boolean validate(String cityPincode) throws InvalidCityPincodeException {
	
		//fill the code
    		
	}

}
