import java.util.Scanner;

public class SnacksDetails {
    public static void bill() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the no of pizzas bought:");
        int noOfPizzas = sc.nextInt();
        System.out.println("Enter the no of puffs bought:");
        int noOfPuffs = sc.nextInt();
        System.out.println("Enter the no of cool drinks bought:");
        int noOfCoolDrinks = sc.nextInt();
        
        int totalPrice = noOfPizzas*100 + noOfPuffs*20 + noOfCoolDrinks*10;
        System.out.println("Bill Details");
        System.out.println("No of pizzas:" + noOfPizzas);
        System.out.println("No of puffs:" + noOfPuffs);
        System.out.println("No of cooldrinks:" + noOfCoolDrinks);
        System.out.println("Total price=" + totalPrice);
        System.out.println("ENJOY THE SHOW!!!");
    }
    
    public static void main(String args[]) {
        bill();
    }
}