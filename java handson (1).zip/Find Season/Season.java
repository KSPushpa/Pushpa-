import java.util.Scanner;
public class Season {
    public static void main(String[] args) {
        String season = null;
        System.out.println("Enter the month:");
        Scanner s = new Scanner(System.in);
        int entry = s.nextInt();
        int flag = 0;
        switch (entry) {
            case 12:
            case 1:
            case 2:
            season = "Winter";
            break;
            case 3:
            case 4:
            case 5:
            season = "Spring";
            break;
            case 6:
            case 7:
            case 8:
            season = "Summer";
            break;
            case 9:
            case 10:
            case 11:
            season = "Autumn";
            break;
            default:
            flag = 1;
       }
       if (flag == 0) 
        System.out.println("Season:" + season);
        else 
        System.out.println("Invalid month");
   }
}
