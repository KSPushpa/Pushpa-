import java.util.Scanner;
public class FindFactor {
    
    public static void printFactors(int input) {
        for (int i = 1; i <= input/2; i++) {
            if (input % i == 0) {
                System.out.print(i + ", ");
            }
        }
        System.out.print(input);
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int input = sc.nextInt();
        
        if (input == 0) {
            System.out.println("No Factors");
        } else if (input < 0) {
            input = -input;
            printFactors(input);
        } else {
            printFactors(input);
        }
    }
}