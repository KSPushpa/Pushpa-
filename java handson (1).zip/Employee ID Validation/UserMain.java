import java.util.Scanner;
public class UserMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your ID");
        String input = sc.nextLine();
        if (input.matches("[G]{1}[B]{1}[L]{1}[/]{1}[0-9]{3}[/]{1}[0-9]{4}")) {
            System.out.println("Login success");
        } else {
            System.out.println("Incorrect ID");
        }
    }
}