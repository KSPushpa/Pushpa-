import java.util.Scanner;
public class CumulativeSum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of elements");
        int noOfElements = sc.nextInt();
        
        if (noOfElements <= 0 || noOfElements > 20) {
            System.out.println("Invalid Range");
        } else {
            System.out.println("Enter the elements");
            int[] array = new int[noOfElements];
            for (int i = 0; i < array.length; i++) {
                array[i] = sc.nextInt();
            }
            
            int sum = 0;
            for (int i = 0; i < noOfElements; i++) {
                sum += array[i];
                System.out.print(sum + " ");
            }
        }
        
        
        
    }
}