import java.util.Scanner;
public class LuckyNum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the car no:");
        int input = sc.nextInt();
        
        if (input >= 10000 || input < 1000) {
            System.out.println(input + " is not a valid car number");
        } else {
            int n = input;
            int sum = 0; 
          
            while (n != 0) 
            { 
                sum = sum + n % 10; 
                n = n/10; 
            } 
            if (sum % 3 == 0 || sum % 5 == 0 || sum % 7 == 0) {
                System.out.println("Lucky Number");
            } else {
                System.out.println("Sorry its not my lucky number");
            }
        }
    }
}