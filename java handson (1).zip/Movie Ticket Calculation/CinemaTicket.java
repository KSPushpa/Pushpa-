import java.util.Scanner;
public class CinemaTicket {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double ticketCost = 0;
        
        System.out.println("Enter the no of ticket:");
        int noOfTickets = sc.nextInt();
        if (noOfTickets >= 5 && noOfTickets <= 40) {
            System.out.println("Do you want refreshment:");
            char refreshmentChoice = sc.next().charAt(0);
            
            
            System.out.println("Do you have coupon code:");
            char couponAvailablity = sc.next().charAt(0);
            
            System.out.println("Enter the circle:");
            char circle = sc.next().charAt(0);
            
            if (circle != 'k' && circle != 'q') {
                System.out.println("Invalid Input");
            }
            else {
                if (circle == 'k') {
                    ticketCost += noOfTickets * 75;
                } else {
                    ticketCost += noOfTickets * 150;
                }
                // bulk booking 
                if (noOfTickets > 20) {
                    ticketCost = ticketCost - (ticketCost * 0.1);
                }
                if (couponAvailablity == 'y') {
                    ticketCost = ticketCost - (ticketCost * 0.02);
                }
                if (refreshmentChoice == 'y') 
                    ticketCost += 50 * noOfTickets;
                System.out.printf("Ticket cost:%.2f", ticketCost);
            }
        } else {
            System.out.println("Minimum of 5 and Maximum of 40 Tickets");
        }   
    }
    
}