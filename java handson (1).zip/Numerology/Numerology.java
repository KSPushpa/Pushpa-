import java.util.Scanner;
public class Numerology {
    private static char[][] data;
    
    public static void loadData() {
        data = new char[][]{{'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
                    'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'}, 
                {'1', '2', '3', '4', '5', '8', '3', '5', '1', '1', '2', '3', '4', '5', '7', '8', '1', '2', 
                    '3', '4', '6', '6', '6', '5', '1', '7'}};
    }
    
    public static boolean validateName(String name) {
        if (name.matches("[A-Z]+")) {
            return true;
        } 
        return false;
    }
    
    public static void main(String[] args) {
        loadData();
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your name:");
        String name = sc.nextLine();
        boolean isValid = validateName(name);
        int n = name.length();
        int numberologyNo = 0;
        
        if (isValid) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < 26; j++) {
                    if (name.charAt(i) == data[0][j]) {
                        numberologyNo += Integer.parseInt(String.valueOf(data[1][j]));
                    }
                }
            }
            System.out.println("Your numerology no is:" + numberologyNo);
            
        } else {
            System.out.println("Invalid name");
        }
    }
}