import java.util.Scanner;
public class CompatibleArrays {
    public static void validateArraySize(int arraySize) {
        if (arraySize <= 0) {
            System.out.println("Invalid array size");
            System.exit(0);
        }
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size for First array:");
        int firstArraySize = sc.nextInt();
        validateArraySize(firstArraySize);
        
        System.out.println("Enter the elements for First array:");
        int[] firstArray = new int[firstArraySize];
        for (int i = 0; i < firstArraySize; i++) {
            firstArray[i] = sc.nextInt();
        }
        System.out.println("Enter the size for Second array:");
        int secondArraySize = sc.nextInt();
        validateArraySize(secondArraySize);
            
        int[] secondArray = new int[secondArraySize];
        System.out.println("Enter the elements for Second array:");
        for (int i = 0; i < secondArraySize; i++) {
            secondArray[i] = sc.nextInt();
        }
        
        int flag = 0;
        if (firstArraySize == secondArraySize) {
            for (int i = 0, j = 0; i < firstArraySize && j < secondArraySize; i++, j++) {
                if(firstArray[i] < secondArray[j]) {
                    flag = 1;
                    break;
                }
            }
            if(flag == 0) {
                System.out.println("Arrays are Compatible");
            } 
        } 
        if (firstArraySize != secondArraySize || flag == 1) {
                System.out.println("Arrays are Not Compatible");
        }
        
    }
}