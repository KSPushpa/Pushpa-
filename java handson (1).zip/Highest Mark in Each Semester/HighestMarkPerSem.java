import java.util.Scanner;
public class HighestMarkPerSem {
    public static int scanMarks(Scanner sc) {
        int input = sc.nextInt();
        if (input < 0 || input > 100) {
            System.out.println("You have entered invalid mark.");
            System.exit(0);
            return -1;
        } 
        return input;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter no of semester:");
        int noOfSemester = sc.nextInt();
        
        int[][] data = new int[noOfSemester][];
        int[] max = new int[noOfSemester];
        for (int i = 0; i < data.length; i++) {
            System.out.println("Enter no of subjects in " + (i+1) + " semester:");
            data[i] = new int[sc.nextInt()];
        }    
        for (int i: max) {
            i = 0;
        }
        
        for (int i = 0; i < data.length; i++) {
            System.out.println("Marks obtained in semester " + (i+1));
            for (int j = 0; j < data[i].length; j++) {
                data[i][j] = scanMarks(sc);
                if (max[i] < data[i][j]) {
                    max[i] = data[i][j];
                }
            }
        }
        
        for (int i = 0; i < max.length; i++) {
            System.out.println("Maximum mark in " + (i+1) + " semester:" + max[i]);
        }
        
        
    }
}