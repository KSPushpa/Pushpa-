import java.util.Scanner;
public class PrimeNumbers {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        System.out.println();
        int b = sc.nextInt();
        
        int i, j, flag;
        
        if (a > 0 && b > 0 && a < b) {
            for (i = a; i <= b; i++) {
                if (i == 1 || i == 0) {
                    continue;
                }
                
                flag = 1;
                
                for (j = 2; j <= i/2; j++) {
                    if (i % j == 0) {
                        flag = 0; 
                        break;
                    }
                }
                
                if (flag == 1) {
                    System.out.print(i + " ");
                }
            }
        }
        else {
            System.out.println("Provide valid input");
        }    
    }
}