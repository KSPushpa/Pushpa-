import java.util.Scanner;
public class InitCap {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the String:");
        String input = sc.nextLine();
        
        String[] words = input.split(" ");
        int count = 0;
        for (int i = 0; i < words.length; i++) {
            if (String.valueOf(words[i].charAt(0)).matches("[A-Z]+")) {
                count++;
            } else {
                words[i] = words[i].substring(0, 1).toUpperCase() + words[i].substring(1, words[i].length());
            }
        }
        
        if (count == words.length) {
            System.out.println("First character of each word is already in uppercase");
        } else {
            for (String word: words) {
                System.out.print(word + " ");
            }
        }
    }
}