import java.util.Scanner;
public class Palindrome {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int original = num;
        int remainder = 0, reversed = 0;
        if (num < 0) {
            System.out.println("Invalid Input");
        } else {
            while( num != 0 ) {
                remainder = num % 10;
                reversed = reversed * 10 + remainder;
                num  /= 10;
            }
    
            if (original == reversed)
                System.out.println("Palindrome");
            else
                System.out.println("Not a Palindrome");
        }
        
    }
}