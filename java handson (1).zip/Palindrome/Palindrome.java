import java.util.Scanner;
public class Palindrome {
    public static void checkPalindrome(String input) {
        String word = input.toLowerCase();
        String reversedWord = "";

        for (int i = word.length()-1; i >= 0; i--) {
            reversedWord += word.charAt(i);
        }

        if (word.equals(reversedWord)) {
            System.out.println(input + " is a Palindrome");
        } else {
            System.out.println(input + " is not a Palindrome");
        }
    }
    
    public static boolean validateInput(String input) {
        if (input.matches("[a-zA-Z]+")) {
            return true;
        }
        return false;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the word :");
        String input = sc.nextLine();
        boolean isValid = validateInput(input);
        if (isValid) {
            checkPalindrome(input);
        } else {
            System.out.println("Invalid Input");
        }
    }
}