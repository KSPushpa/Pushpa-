import java.util.Scanner;
public class IncrementCalculation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the salary");
        double salary = sc.nextDouble();
        
        System.out.println("Enter the Performance appraisal rating");
        double appraisalRating = sc.nextDouble();
        
        if (salary <= 0 || appraisalRating < 1 || appraisalRating > 5) {
            System.out.println("Invalid Input");
        } else {
            if (appraisalRating >= 1 && appraisalRating <= 3) {
                salary += salary * 0.1;
            }
            if (appraisalRating >= 3.1 && appraisalRating <= 4) {
                salary += salary * 0.25;
            }
            if (appraisalRating >= 4.1 && appraisalRating <= 5) {
                salary += salary * 0.3;
            }
            
            System.out.println((int)salary);
        }
    }
}