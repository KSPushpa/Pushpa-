import java.util.Scanner;
import java.util.regex.Pattern;
public class UniqueChar {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Sentence:");
        String input = sc.nextLine(); 
        
        input = input.replaceAll(" ", "");
        
        boolean isValid = input.matches("[a-zA-Z]+");
        
        if (!isValid) {
             System.out.println("Invalid Sentence");
        }
        else {
            int[] count = new int[256];
            
            for (int i = 0; i < input.length(); i++) {
                count[(int)input.charAt(i)]++; 
            }
            
            int flag = 0;
            String uniqueCharacters = "";
            for (int i = 0; i < input.length(); i++) {
                if (count[(int)input.charAt(i)] == 1) {
                    uniqueCharacters = uniqueCharacters + input.charAt(i) + "\n";
                    flag = 1;
                }
            }
            if (flag == 1) {
                System.out.println("Unique characters:");
                System.out.println(uniqueCharacters);
            } else {
                System.out.println("No unique characters");
            }
        } 
 
    }
}