import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Generate your Security Code");
        String input = sc.nextLine();
        if (input.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[*@#])(?=\\S+$).{8,}$")) {
            System.out.println("Security Code Generated Successfully");
        } else {
            System.out.println("Invalid Security Code, Try Again!");
        }
    }
}