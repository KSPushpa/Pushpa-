import java.util.Scanner;
public class Course {
    public static void searchCourse() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter no of course:");
        int noOfCourse = sc.nextInt();
        
        if (noOfCourse <= 0 || noOfCourse > 20) {
            System.out.println("Invalid Range");
        } else {
        
            System.out.println("Enter course names:");
            String[] courses = new String[noOfCourse];
            for (int i = 0; i < courses.length; i++) {
                courses[i] = sc.next();
            }
            
            System.out.println("Enter the course to be searched:");
            String input = sc.next();
            int flag = 0;
            for (String course: courses) {
                if (course.equals(input)) {
                    flag = 1;
                    break;
                } 
            }
            if (flag == 1) {
                System.out.println(input + " course is available");
            } else {
                System.out.println(input + " course is not available");
            }
        }
    }
    
    public static void main(String[] args) {
        searchCourse();
    }
}