import java.util.Scanner;
public class ReplaceWord {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the string:");
        String input = sc.nextLine();
        System.out.println("Enter the word to be searched:");
        String searchString = sc.nextLine();
        
        System.out.println("Enter the word to be replaced:");
        String replaceString = sc.nextLine();
        
        if (!input.contains(searchString)) {
            System.out.println("The word " + searchString + " not found");
        } else {
            input = input.replace(searchString, replaceString);
            System.out.println(input);
        }
    }
}