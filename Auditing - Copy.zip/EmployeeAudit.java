import java.util.ArrayList;

public interface EmployeeAudit {

	// Fill the code
	public ArrayList<String> fetchEmployeeDetails (double salary);
}
