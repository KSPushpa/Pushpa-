import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.*;
public class Main {
	
	private static Map <String,Double> employeeMap=new TreeMap<String,Double>();

	public Map<String, Double> getEmployeeMap() {
		return employeeMap;
	}

	public void setEmployeeMap(Map<String, Double> employeeMap) {
		this.employeeMap = employeeMap;
	}
	
	public void addEmployeeDetails(String employeeName, double salary)
	{
		// Fill the code
		Map <String,Double> employeeMap=getEmployeeMap();
		employeeMap.put(employeeName,salary);
		setEmployeeMap(employeeMap);
		
	}
	
	
	
	public static EmployeeAudit findEmployee()
	{
		// Fill the code
		EmployeeAudit obj=(double salary)-> {
		    Set<String> keySet=employeeMap.keySet();
		    ArrayList<String> name=new ArrayList<>();
		    for(String key:keySet){
		        if(employeeMap.get(key)<=salary){
		            name.add(key);
		        }
		    }
		   return name;
		};
		
	return obj;
		
	}
	
	public static void main(String[] args)
	{
		
		Scanner sc=new Scanner(System.in);
		
		// Fill the code
		Main m = new Main();
		while(true){
		System.out.println("1.Add Employee Details");
		System.out.println("2.Find Employee Details");
		System.out.println("3.Exit");
		System.out.println("Enter the choice");
		int o=sc.nextInt();
		    if(o==1){
		        System.out.println("Enter the Employee name");
		        String name=sc.next();
		        System.out.println("Enter the Employee Salary");
		        double salary=sc.nextDouble();
		        m.addEmployeeDetails(name,salary);
		    }
		    if(o==2){
		        System.out.println("Enter the salary to be searched");
		        double salary=sc.nextDouble();
		        boolean f=m.findEmployee().fetchEmployeeDetails(salary).isEmpty();
		        if(f==false){
		        System.out.println("Employee List");
		        ArrayList<String> name=m.findEmployee().fetchEmployeeDetails(salary);
		        for(String n:name){
		            System.out.println(n);
		        }
		        }
		        else{
		            System.out.println("No Employee Found");
		        }
		        
		    }
		    if(o==3){
		        System.out.println("Let's complete the session");
		        return;
		        
		    }
		}
		
		
	}

}
