import java.util.Scanner;
import java.util.regex.*;
public class Authority{

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);

        System.out.println("Inmate's name:");
        String Inmate = s.nextLine();
        
         System.out.println("Inmate's father's name:");
        String father = s.nextLine();

         if(!Pattern.matches("^[ A-Za-z]+$",Inmate))

         {

             System.out.println("Invalid name");

         }
         
          else if(!Pattern.matches("^[ A-Za-z]+$",father))

         {

             System.out.println("Invalid name");

         }

         else
         {
             String k = Inmate + " " + father;
             System.out.println(k.toUpperCase());
         }

        

        

              

    }

}