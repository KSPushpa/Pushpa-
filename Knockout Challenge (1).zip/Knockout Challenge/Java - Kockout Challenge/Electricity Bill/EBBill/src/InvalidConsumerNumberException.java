public class InvalidConsumerNumberException extends Exception {
    public InvalidConsumerNumberException(String message) {
        super(message);
    }
}