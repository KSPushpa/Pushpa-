
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// fill your code here
		Train t=new Train();
		TrainManagementSystem ts=new TrainManagementSystem();
		System.out.println("Enter the source");
		String source=sc.next();
		t.setSource(source);
		System.out.println("Enter the destination");
		String destination=sc.next();
		t.setDestination(destination);
		System.out.println("Enter the coach type");
		String coachType=sc.next();
		
		if(coachType.equalsIgnoreCase("ac1")||coachType.equalsIgnoreCase("ac2")||coachType.equalsIgnoreCase("ac3")||coachType.equalsIgnoreCase("sleeper")||coachType.equalsIgnoreCase("seater")){
		    ts.viewTrain(coachType,source,destination);
		}
		else{
		    System.out.println("Invalid Coach Type");
		}

		
	}
}