
import java.util.ArrayList;
import java.util.*;
import java.sql.*;

public class TrainManagementSystem {
	
	public ArrayList <Train> viewTrain (String coachType, String source, String destination){
		
		// Fill your code here	
		ArrayList<Train> t=new ArrayList<>();
		try{
		    Connection conn=DB.getConnection();
		    Statement stmt=conn.createStatement();
		    String s="SELECT train_number,train_name,"+coachType+" from train where source='"+source+"' && destination='"+destination+"' && "+coachType+">0 order by train_number";
		    ResultSet rs = stmt.executeQuery(s);
		    
		    while(rs.next()){
		        Train train = new Train();
		       
		        train.setTrainNumber(rs.getInt("train_number"));
		        train.setTrainName(rs.getString("train_name"));
		        t.add(train);
		    }
		    if(t.isEmpty()){
		        System.out.println("No trains found");
		    }
		    for(Train tr:t){
		        System.out.println(tr.getTrainNumber()+" "+tr.getTrainName());
		    }
		   // return t;
		    
		}
		catch(Exception e){
		    e.printStackTrace();
		}
		return t;
		
	}

}
