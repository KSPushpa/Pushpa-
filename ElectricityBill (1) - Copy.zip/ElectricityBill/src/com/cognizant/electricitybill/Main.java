package com.cognizant.electricitybill;


import java.util.List;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ElectricityBoard electricityBoard=new ElectricityBoard();
		List<ElectricityBill> electricityBill=electricityBoard.generateBill("src/ElectricityBill.txt");
		electricityBoard.addBill(electricityBill);
		
	}

}
