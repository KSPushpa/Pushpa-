package com.cognizant.electricitybill;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ElectricityBoard {
	public List<ElectricityBill> generateBill(String filePath){
		List<ElectricityBill> electricityBillList=new ArrayList<ElectricityBill>();
		try {
			BufferedReader bufferedReader=new BufferedReader(new FileReader(filePath));
			Scanner scanner=new Scanner(bufferedReader);
			while(scanner.hasNext()) {
				String[] records=scanner.nextLine().split(",");
				String consumerNumber=records[0];
				boolean validate=validate(consumerNumber);
				if(validate) {
					ElectricityBill electricityBill=new ElectricityBill();
					String consumerName=records[1];
					String consumerAddress=records[2];
					int unitsConsumed=Integer.parseInt(records[3]);
					
					electricityBill.setConsumerNumber(consumerNumber);
					electricityBill.setConsumerName(consumerName);
					electricityBill.setConsumerAddress(consumerAddress);
					electricityBill.setUnitsConsumed(unitsConsumed);
					electricityBill.calculateBillAmount();
					electricityBillList.add(electricityBill);
					return electricityBillList;
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (InvalidConsumerNumberException e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	public boolean validate(String consumerNumber) throws InvalidConsumerNumberException {
		Pattern pattern=Pattern.compile("[0]{1}[0-9]{9}");
		Matcher matcher=pattern.matcher(consumerNumber);
		if(matcher.matches()) {
			return true;
		}
		else {
			throw new InvalidConsumerNumberException("Invalid Consumer Number");
		}
		
	}
	
	void addBill(List<ElectricityBill> billList) {
		List<ElectricityBill> electricityBillList=billList;
		DBHandler dbHandler=new DBHandler();
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		//ResultSet resultSet=null;
		ElectricityBill electricityBill=new ElectricityBill();
		
		try {
			connection=dbHandler.establishConnection();
			String query="insert into ElectricityBill values(?,?,?,?,?);";
			preparedStatement=connection.prepareStatement(query);
			for (ElectricityBill electricityBill1 : electricityBillList) {
				preparedStatement.setString(1, electricityBill1.getConsumerNumber());
				preparedStatement.setString(2, electricityBill1.getConsumerName());
				preparedStatement.setString(3, electricityBill1.getConsumerAddress());
				preparedStatement.setInt(4, electricityBill1.getUnitsConsumed());
				preparedStatement.setDouble(5, electricityBill1.getBillAmount());
				preparedStatement.executeUpdate();
			}
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
}
