package com.cognizant.electricitybill;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBHandler {
	private static Connection connection=null;
	private static Properties properties=new Properties();
	
	public static Connection establishConnection() throws IOException, ClassNotFoundException, SQLException {
		FileInputStream fileInputStream=new FileInputStream("src/db.properties");
		properties.load(fileInputStream);
		Class.forName(properties.getProperty("driver"));
		connection=DriverManager.getConnection(properties.getProperty("connection-url"),properties.getProperty("username"),
				properties.getProperty("password"));
		return connection;
	}
}
