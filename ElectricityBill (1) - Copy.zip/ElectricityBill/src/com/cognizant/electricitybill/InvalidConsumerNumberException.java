package com.cognizant.electricitybill;

public class InvalidConsumerNumberException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidConsumerNumberException() {
		super();
	}

	public InvalidConsumerNumberException(String message) {
		super(message);
	}

}
