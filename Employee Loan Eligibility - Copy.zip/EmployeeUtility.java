import java.util.stream.Stream;
import java.util.*;
import java.util.stream.*;
public class EmployeeUtility {

	public Employee[] getEmployeeDetails(String[] details) {
		//Fill your code here
		Employee[] e=new Employee[details.length];
		for(int i=0;i<details.length;i++){
		    String[] emp=details[i].split(";");
		    e[i]=new Employee();
		    e[i].setEmpId(emp[0]);
		    e[i].setEmpName(emp[1]);
		    e[i].setSalary(Double.parseDouble(emp[2]));
		    
		}
        return e;
	}

	public Stream<Employee> getStreamOfEmployee(Employee[] empDetails) {
		//Fill your code here
        Stream<Employee> stream1=Arrays.stream(empDetails);
        return stream1;
	}

	public String[] shortlistedEmployee(Stream<Employee> empStream,double minSalary) {

	  List<Employee> list = empStream.filter(e->e.getSalary()>=minSalary).sorted((e1, e2) -> e1.getEmpId().compareTo(e2.getEmpId())).collect(Collectors.toList());
        int i=0;
        String[] shortlistedEmployee=new String[list.size()];
        for(Employee employee:list) {
        	shortlistedEmployee[i++] = employee.getEmpId()+" "+employee.getEmpName()+" "+employee.getSalary();
        }
        return shortlistedEmployee;
        
	}

}
